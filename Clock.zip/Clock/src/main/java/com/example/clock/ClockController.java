package com.example.clock;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.util.Duration;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class ClockController implements Initializable{

    @FXML
    private Label dateLabel;

    @FXML
    private Label dayLabel;

    @FXML
    private Label timeLabel;

    Date date;

            /*
                hh = hour;
                mm = minute;
                ss = second;
                a = am / pm;
                E = day name (Mon, Tue etc);
                EEEE = day name (Monday, Tuesday, etc);
                dd = date;
                MM = month number (1, 2, 3 etc);
                MMMMM = name of month (January feberary, etc);
                yyyy = year;
            */

    Timeline timeline=new Timeline(new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>(){

        @Override
        public void handle(ActionEvent actionEvent){
            date=new Date();
            timeLabel.setText(new SimpleDateFormat("hh : mm : ss a").format(date));
            dayLabel.setText(new SimpleDateFormat("EEEE").format(date));
            dateLabel.setText(new SimpleDateFormat("dd MMMMM yyyy").format(date));
        }
    }));

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
}
